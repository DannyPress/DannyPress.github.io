# Daniel Pressler Midterm Report

## 1. Summary Section

    In this project I wanted to learn if companies in the SP500 would have high returns around when their 10ks were released. I also wanted to learn if companies that had higher sentiment analysis scores would have higher returns based of a measurement that I created. To give you a big summary of what happen, I learned alot about downloading and manipulating data in my build_sample note book with previous stock data over the year in 2022. In this note book I created a series of varaibles that are all data frames of companies cumulative stock returns that revolved around their 10k filing dates. After many loops and functions I created I was able to get all the data that I needed. I also had to do a sentiment analysis on all the companies 10ks that I downloaded and created a measurement strategy to score companies 10ks if they had a lot of positive words or negative words in their 10ks. To go more indepth I did a contextual sentiment analysis which to explain in baby terms I used a sepcific program to measure the sentiment of a sentence that was related to a topic of my choosing. The topics that I chose were ai, ESG, and DEI.

## 2. Data Section

What's the sample
ntiment variables works.


    Below are all the data points that are currently in the analysis sample
    - CIK numbers
    - Ticker symbols
    - 10k filing dates
    - The returns companies had on the day they filed their 10k
    - The cumulative return a company had after filing their 10k from day 0 to day 3
    - The cumulative return a company had after filing their 10k from day 3 to day 10 
    - The sentiment scores for each company based of positive and negative word count in their given 10k
    - The contextual sentiment scores for each company based of positive and negative word count that revolved around topic like AI, DEI, and ESG.

How are the return variables built and modified? (Mechanical description.) Aim for rigor and do not skip steps. You can include text and formulas here.


    For version 1 I did a simple merge on the data frame that contained the returns on the SP500 from the past year and the data where I got all the CIK numbers, accession numbers, and filing dates. When merging this I merged on ticker and Filing date and did a left merge because I wanted to keep everything in the left data frame that was originally there. The left data frame was the data frame that had all the CIK numbers
    For version 2 I played around with the stocks data from the SP500 to learn what data is from each index for one stock and realized that the index after a previous one was just the return data for the next business day. So for version 2 I put in code that sorted the values based on ticker and date column. Then I reseted the index just in case because it is good practice for this strategy. Then I created a nested for loop with some checks to see if there was empty data in my data frame. In the nested for loop it changes the indexes from 0 to 3 to grab the return data and put each data point into its own column in the right row. Then I have code that grabs the data from each column and calculates the cumulative return over those three days and adds it to a new column in each row
    For version 3 I basically just copied the same code and just changed the for loops to loop through 3 to 11 and it used those numbers when grabbing the returns from the different days by adding the index to where it originally started. The code is essentially the same except some minor details that were changed.


How are the sentiment variables are built and modified? (Mechanical description.) Aim for rigor and do not skip steps. You can include text and formulas here.


    For the sentiment variables use code that reads the CSV file that had all the positive and negative words and used to go put it all into a list. Then I used code put the list into one string and put this “|” between each word. For Q3 and Q4 I used the .lower() function to put everything in the string to be lowercase. For getting the right words in the LM excel file I added everything to a list that didn’t equal zero so it would grab everything that had a year. After reading the academic paper I learned the year was when the word was added to be positive or negative in the list    The next part I had code that pulls the 10k zip file and opens it. I created two functions that calculate the sentiment score and grab the cik number so it could be put into the data. Getting the CIK number was important for me merging the data later on. In the function after I call the previous function in a loop to add it all to a dataframe. It was important when going through this process I did all the sentiment variables for 5 firms then at the end changed the code in the for loop to do all 498 that I grabbed. Then I call the function the second function to run everything. Overall for all these variables I just figured out the code for one of them and just copy and pasted the code to find the other variables and did some minor changes to each.



These datapoints about the sentiment variables:


    Their are 354 words in the LM positive dictionary
    Their are 2355 words in the LM negative dictionary
    Their are 75 words in the ML positive dictionary
    Their are 94 words in the ML negative dictionary
    For setting up the near_regex function I this code to import the function into the build sample notebook ```from near_regex import NEAR_regex ```

Why did you choose the three topics you did for the “contextual sentiment” measures?

    I chose the three topics I picked because they are three relevant topics that are commonly discussed in major corporations over the past couple of years. Since covid companies have exponentially grown with gaining better technology to make more processes more efficient. This could lead to companies making more of a profit at lower costs too. Next was the ESG topic which has been important because now companies get ESG scores and this can positively or negatively impact a company's stock price. Lastly, I chose the DEI topic because that is another topic that has been leaving a major impact on companies recently. I believe if companies demonstrate that they will grow their DEI effects, this can be seen as good press which could positively affect a company's stock and vice versa


Do your “contextual sentiment” measures pass some basic smell tests?


Smell tests: Is something fishy?     Nothing is fishy about my contextual sentiment part. The scores for all of them are really low which isn’t surprising since it is only searching for 5 words compared to a list that has around 50 words so the scores would be smaller than the first four variables
Do you have variation in the measures
    I don’t have variation in my answers. What I ended up doing was creating code that would give me a data frame with scores for one of the contextual sentiment variables and once I got it, I just copy and pasted the code for the rest of the variables and make the minor adjustments that were necessary.

Industries question    I am getting hirer scores for positive contextual sentiment variables compared to the negative. I am willing to bet that most companies would want to find ways to legally demonstrate a good outlook on their company compared to a negative look





Are there any caveats about the sample and/or data? If so, mention them and briefly discuss possible issues they raise with the analysis.


    In my Q1 sentiment variable my sentiment score is off by a lot but the code for the other sentiment variables works.


## 3. Results


```python
# importing the data set
import matplotlib.pyplot as plt
import pandas as pd
file_path = 'output/analysis_sample.csv'
df = pd.read_csv(file_path)
new_df = pd.DataFrame(df)
print(new_df.head()) 
```

        CIK Filing Date ticker       ret  Cumulative Return t to t+2  \
    0  1800  2022-02-18    ABT -0.031431                   -0.027617   
    1  2488  2022-02-03    AMD -0.021831                    0.007413   
    2  2969  2022-11-22    APD  0.043015                    0.045545   
    3  4127  2022-11-23   SWKS  0.008601                   -0.031217   
    4  4281  2022-02-14    HWM -0.007863                    0.040478   
    
       Cumulative Return t+3 to t+10  Negative BHR Sentiment Score  \
    0                       0.013731                      0.036660   
    1                      -0.091372                      0.037781   
    2                       0.018296                      0.041740   
    3                       0.043073                      0.038842   
    4                      -0.073328                      0.038538   
    
       Positive BHR Sentiment Score  Negative LM Sentiment Score  \
    0                      0.036927                     0.037373   
    1                      0.037331                     0.044509   
    2                      0.054153                     0.037519   
    3                      0.042319                     0.039587   
    4                      0.044700                     0.038999   
    
       Positive LM Sentiment Score  Innovation Positive Sentiment Score  \
    0                     0.013772                             0.000018   
    1                     0.017415                             0.000126   
    2                     0.022021                             0.000044   
    3                     0.017757                             0.000224   
    4                     0.021313                             0.000046   
    
       Innovation Negative Sentiment Score  ESG Negative Sentiment Score  \
    0                             0.000161                      0.000000   
    1                             0.000234                      0.000000   
    2                             0.000044                      0.000074   
    3                             0.000149                      0.000025   
    4                             0.000092                      0.000015   
    
       ESG Positive Sentiment Score  DEI Positive Sentiment Score  \
    0                      0.000036                      0.000107   
    1                      0.000000                      0.000720   
    2                      0.000118                      0.001063   
    3                      0.000000                      0.000174   
    4                      0.000015                      0.000154   
    
       DEI Negative Sentiment Score  
    0                      0.000125  
    1                      0.000306  
    2                      0.000443  
    3                      0.000050  
    4                      0.000277  
    

Correlation table


```python
sentiment_columns = new_df.columns[6:]
return_columns = new_df.columns[3:6]
correlation_table = pd.DataFrame(index=sentiment_columns, columns=return_columns)
for sentiment in sentiment_columns:
    for ret in return_columns:
        correlation = df[sentiment].corr(df[ret]) 
        correlation_table.at[sentiment, ret] = correlation 
print(correlation_table)
```

                                              ret Cumulative Return t to t+2  \
    Negative BHR Sentiment Score         0.051762                   0.083226   
    Positive BHR Sentiment Score        -0.009049                  -0.024221   
    Negative LM Sentiment Score         -0.016591                  -0.039426   
    Positive LM Sentiment Score         -0.050051                  -0.143516   
    Innovation Positive Sentiment Score -0.089341                  -0.098946   
    Innovation Negative Sentiment Score -0.082703                  -0.056317   
    ESG Negative Sentiment Score         0.024834                   0.080636   
    ESG Positive Sentiment Score        -0.033623                   0.003514   
    DEI Positive Sentiment Score         0.052034                   0.014755   
    DEI Negative Sentiment Score         0.056741                  -0.023613   
    
                                        Cumulative Return t+3 to t+10  
    Negative BHR Sentiment Score                            -0.007724  
    Positive BHR Sentiment Score                             -0.03127  
    Negative LM Sentiment Score                             -0.055313  
    Positive LM Sentiment Score                             -0.080507  
    Innovation Positive Sentiment Score                     -0.012526  
    Innovation Negative Sentiment Score                     -0.020897  
    ESG Negative Sentiment Score                             0.192955  
    ESG Positive Sentiment Score                             0.158436  
    DEI Positive Sentiment Score                            -0.055801  
    DEI Negative Sentiment Score                            -0.044232  
    

Scatter Plots


```python
plt.scatter(new_df['Cumulative Return t to t+2'], new_df['Negative BHR Sentiment Score'],label='t to t+2',  marker='o', linestyle='-', color='b') 
plt.scatter(new_df['Cumulative Return t+3 to t+10'], new_df['Negative BHR Sentiment Score'], label='t+3 to t+10', marker='s', linestyle='--', color='r')  
plt.title('Comparison of ML negative values and returns')
plt.xlabel('Returns')
plt.ylabel('Negative BHR Sentiment Score')
plt.legend()
plt.grid(True)
plt.show()
```


    
![png](output_23_0.png)
    



```python
plt.scatter(new_df['Cumulative Return t to t+2'], new_df['Positive BHR Sentiment Score'],label='t to t+2',  marker='o', linestyle='-', color='b') 
plt.scatter(new_df['Cumulative Return t+3 to t+10'], new_df['Positive BHR Sentiment Score'], label='t+3 to t+10', marker='s', linestyle='--', color='r')  
plt.title('Comparison of ML positive values and returns')
plt.xlabel('Returns')
plt.ylabel('Positive BHR Sentiment Score')
plt.legend()
plt.grid(True)
plt.show()
```


    
![png](output_24_0.png)
    



```python
plt.scatter(new_df['Cumulative Return t to t+2'], new_df['Negative LM Sentiment Score'],label='t to t+2',  marker='o', linestyle='-', color='b') 
plt.scatter(new_df['Cumulative Return t+3 to t+10'], new_df['Negative LM Sentiment Score'], label='t+3 to t+10', marker='s', linestyle='--', color='r')  
plt.title('Comparison of Negative LM Sentiment Score and returns')
plt.xlabel('Returns')
plt.ylabel('Negative LM Sentiment Score')
plt.legend()
plt.grid(True)
plt.show()
```


    
![png](output_25_0.png)
    



```python
plt.scatter(new_df['Cumulative Return t to t+2'], new_df['Positive LM Sentiment Score'],label='t to t+2',  marker='o', linestyle='-', color='b') 
plt.scatter(new_df['Cumulative Return t+3 to t+10'], new_df['Positive LM Sentiment Score'], label='t+3 to t+10', marker='s', linestyle='--', color='r')  
plt.title('Comparison of Positive LM Sentiment Score and returns')
plt.xlabel('Returns')
plt.ylabel('Positive LM Sentiment Score')
plt.legend()
plt.grid(True)
plt.show()
```


    
![png](output_26_0.png)
    



```python
plt.scatter(new_df['Cumulative Return t to t+2'], new_df['Innovation Positive Sentiment Score'],label='t to t+2',  marker='o', linestyle='-', color='b') 
plt.scatter(new_df['Cumulative Return t+3 to t+10'], new_df['Innovation Positive Sentiment Score'], label='t+3 to t+10', marker='s', linestyle='--', color='r')  
plt.title('Comparison of Innovation Positive Sentiment Score and returns')
plt.xlabel('Returns')
plt.ylabel('Innovation Positive Sentiment Score')
plt.legend()
plt.grid(True)
plt.show()
```


    
![png](output_27_0.png)
    



```python
plt.scatter(new_df['Cumulative Return t to t+2'], new_df['Innovation Negative Sentiment Score'],label='t to t+2',  marker='o', linestyle='-', color='b') 
plt.scatter(new_df['Cumulative Return t+3 to t+10'], new_df['Innovation Negative Sentiment Score'], label='t+3 to t+10', marker='s', linestyle='--', color='r')  
plt.title('Comparison of Innovation Negative Sentiment Score and returns')
plt.xlabel('Returns')
plt.ylabel('Innovation Negative Sentiment Score')
plt.legend()
plt.grid(True)
plt.show()
```


    
![png](output_28_0.png)
    



```python
plt.scatter(new_df['Cumulative Return t to t+2'], new_df['ESG Negative Sentiment Score'],label='t to t+2',  marker='o', linestyle='-', color='b') 
plt.scatter(new_df['Cumulative Return t+3 to t+10'], new_df['ESG Negative Sentiment Score'], label='t+3 to t+10', marker='s', linestyle='--', color='r')  
plt.title('Comparison of ESG Negative Sentiment Score and returns')
plt.xlabel('Returns')
plt.ylabel('ESG Negative Sentiment Score')
plt.legend()
plt.grid(True)
plt.show()
```


    
![png](output_29_0.png)
    



```python
plt.scatter(new_df['Cumulative Return t to t+2'], new_df['ESG Positive Sentiment Score'],label='t to t+2',  marker='o', linestyle='-', color='b') 
plt.scatter(new_df['Cumulative Return t+3 to t+10'], new_df['ESG Positive Sentiment Score'], label='t+3 to t+10', marker='s', linestyle='--', color='r')  
plt.title('Comparison of ESG Positive Sentiment Score and returns')
plt.xlabel('Returns')
plt.ylabel('ESG Positive Sentiment Score')
plt.legend()
plt.grid(True)
plt.show()
```


    
![png](output_30_0.png)
    



```python
plt.scatter(new_df['Cumulative Return t to t+2'], new_df['DEI Positive Sentiment Score'],label='t to t+2',  marker='o', linestyle='-', color='b') 
plt.scatter(new_df['Cumulative Return t+3 to t+10'], new_df['DEI Positive Sentiment Score'], label='t+3 to t+10', marker='s', linestyle='--', color='r')  
plt.title('Comparison of DEI Positive Sentiment Score and returns')
plt.xlabel('Returns')
plt.ylabel('DEI Positive Sentiment Score')
plt.legend()
plt.grid(True)
plt.show()
```


    
![png](output_31_0.png)
    



```python
plt.scatter(new_df['Cumulative Return t to t+2'], new_df['DEI Negative Sentiment Score'],label='t to t+2',  marker='o', linestyle='-', color='b') 
plt.scatter(new_df['Cumulative Return t+3 to t+10'], new_df['DEI Negative Sentiment Score'], label='t+3 to t+10', marker='s', linestyle='--', color='r')  
plt.title('Comparison of DEI Negative Sentiment Score and returns')
plt.xlabel('Returns')
plt.ylabel('DEI Negative Sentiment Score')
plt.legend()
plt.grid(True)
plt.show()
```


    
![png](output_32_0.png)
    

